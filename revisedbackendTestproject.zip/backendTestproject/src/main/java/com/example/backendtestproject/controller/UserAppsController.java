//package com.example.backendtestproject.controller;
//
//
//import com.example.backendtestproject.model.ApplicationInfo;
//import com.example.backendtestproject.model.User;
//import com.example.backendtestproject.model.UserApps;
//import com.example.backendtestproject.model.UserAppsDto;
//import com.example.backendtestproject.repository.ApplicationInfoRepository;
//import com.example.backendtestproject.repository.UserAppsRepository;
//import com.example.backendtestproject.repository.UserRepository;
//import lombok.RequiredArgsConstructor;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.sql.Timestamp;
//import java.util.List;
//
//@RestController
//@RequiredArgsConstructor
//@CrossOrigin("http://localhost:5173")
//public class UserAppsController {
//
//
//    @Autowired
//    private final UserAppsRepository userAppsRepository;
//
//    @Autowired
//    private final ApplicationInfoRepository applicationInfoRepository;
//
//    @Autowired
//    private final UserRepository userRepository;
//
//
//    @PutMapping("/userapp")
//    public ResponseEntity<?> newUserApps(@RequestBody UserAppsDto userAppsDto) {
//
//        // application id : 2
//        // user id : 1
//
//       // System.out.println("user id: " + userAppsDto.getUserId());
//       // System.out.print("application id : "+ userAppsDto.getApplicationInfoId());
//
////        User user = userRepository.findById(userAppsDto.getUserId()).orElse(null);
////        ApplicationInfo applicationInfo = applicationInfoRepository.findById(userAppsDto.getApplicationInfoId()).orElse(null);
////
////
////        UserApps newUserApps = new UserApps();
////        newUserApps.setApplicationInfo(applicationInfo);
////        newUserApps.setUser(user);
////        newUserApps.setCreated_at(new Timestamp(System.currentTimeMillis()));
////        newUserApps.setCreated_by("admin");
////        newUserApps.setModified_at(new Timestamp(System.currentTimeMillis()));
//
//
//        //return new ResponseEntity<>(userAppsRepository.save(newUserApps), HttpStatus.CREATED);
//        return new ResponseEntity<>(new UserApps(), HttpStatus.OK);
//    }
//
//    @GetMapping("/userapps")
//    List<UserApps> getAllUserApps() {
//        return userAppsRepository.findAll();
//    }
//}