package com.example.backendtestproject.model;

import com.example.backendtestproject.model.ApplicationInfo;
import com.example.backendtestproject.model.User;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import java.sql.Timestamp;

@Data
@Entity

public class UserApps {

    @Id
    @JsonIgnore
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long user_app_uid;

    @ManyToOne
    @JoinColumn(name = "appInfoUid")
    @JsonIgnore
    private ApplicationInfo applicationInfo;


    @ManyToOne
    @JoinColumn(name = "userUid")
    @JsonIgnore
    private User user;

    private Timestamp created_at;
    private String created_by;
    private Timestamp modified_at;
    private String modified_by;

}
