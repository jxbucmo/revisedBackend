package com.example.backendtestproject.model;

import jakarta.persistence.*;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

@Entity
public class ApplicationInfo {

    @Id
    //@GeneratedValue
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Integer appInfoUid;

    private String appInfoDescription;

    private Timestamp createdAt;

    private String createdBy;

    private Timestamp modifiedAt;

    private String modifiedBy;


    //
    @OneToMany(mappedBy = "applicationInfo")
    private List<UserApps> userapps = new ArrayList<>();
    //

    // Constructors, getters, and setters

    public Integer getAppInfoUid() {
        return appInfoUid;
    }

    public void setAppInfoUid(Integer appInfoUid) {
        this.appInfoUid = appInfoUid;
    }

    public String getAppInfoDescription() {
        return appInfoDescription;
    }

    public void setAppInfoDescription(String appInfoDescription) {
        this.appInfoDescription = appInfoDescription;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getModifiedAt() {
        return modifiedAt;
    }

    public void setModifiedAt(Timestamp modifiedAt) {
        this.modifiedAt = modifiedAt;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }
}