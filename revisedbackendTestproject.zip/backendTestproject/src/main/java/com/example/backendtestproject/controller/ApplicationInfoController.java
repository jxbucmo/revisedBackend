package com.example.backendtestproject.controller;

import com.example.backendtestproject.model.ApplicationInfo;
import com.example.backendtestproject.model.User;

import com.example.backendtestproject.model.UserApps;
import com.example.backendtestproject.model.UserAppsDto;
import com.example.backendtestproject.repository.ApplicationInfoRepository;
import com.example.backendtestproject.repository.UserAppsRepository;
import com.example.backendtestproject.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.util.List;

@RestController
@CrossOrigin("http://localhost:5173")
public class ApplicationInfoController {

    @Autowired
    private ApplicationInfoRepository applicationInfoRepository;


    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserAppsRepository userAppsRepository;


    @PostMapping("/appinfo")
    ApplicationInfo newApplicationInfo(@RequestBody ApplicationInfo newApplicationInfo) {
        return applicationInfoRepository.save(newApplicationInfo);
    }

    @GetMapping("/appinfos")
    List<ApplicationInfo> getAllApplicationInfo() {
        return applicationInfoRepository.findAll();
    }



    @PutMapping("/userapp")
    public ResponseEntity<?> newUserApps(@RequestBody UserAppsDto userAppsDto) {

        // application id : 2
        // user id : 1

        System.out.println("user id: " + userAppsDto.getUserId());
        System.out.print("application id : "+ userAppsDto.getApplicationInfoId());

        User user = userRepository.findById(userAppsDto.getUserId()).orElse(null);
        ApplicationInfo applicationInfo = applicationInfoRepository.findById(userAppsDto.getApplicationInfoId()).orElse(null);


        if(user!= null && applicationInfo!=null){
            UserApps newUserApps = new UserApps();
            newUserApps.setApplicationInfo(applicationInfo);
            newUserApps.setUser(user);
            newUserApps.setCreated_at(new Timestamp(System.currentTimeMillis()));
            newUserApps.setCreated_by("admin");
            newUserApps.setModified_at(new Timestamp(System.currentTimeMillis()));

            return new ResponseEntity<>(userAppsRepository.save(newUserApps), HttpStatus.CREATED);
        }else{

            return new ResponseEntity<>(new UserApps(), HttpStatus.OK);
        }


        //return new ResponseEntity<>(new UserApps(), HttpStatus.OK);
    }

    @GetMapping("/userapps")
    List<UserApps> getAllUserApps() {
        return userAppsRepository.findAll();
    }
}


