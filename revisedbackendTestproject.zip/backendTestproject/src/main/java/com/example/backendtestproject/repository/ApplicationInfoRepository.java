package com.example.backendtestproject.repository;

import com.example.backendtestproject.model.ApplicationInfo;
import com.example.backendtestproject.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface ApplicationInfoRepository extends JpaRepository<ApplicationInfo, Integer> {
}
