package com.example.backendtestproject.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import java.sql.Timestamp;

@Entity
public class ServerInfo {

    @Id
    @GeneratedValue
    private Integer serverInfoUid;

    private Integer appInfoUid;

    private String sourceHostname;

    private String sourceIpAddress;

    private String destinationHostName;

    private String destinationIpAddress;

    private String destinationPort;

    private String ipStatus;

    private Timestamp createdAt;

    private String createdBy;

    private Timestamp modifiedAt;

    private String modifiedBy;

    // Constructors, getters, and setters

    public Integer getServerInfoUid() {
        return serverInfoUid;
    }

    public void setServerInfoUid(Integer serverInfoUid) {
        this.serverInfoUid = serverInfoUid;
    }

    public Integer getAppInfoUid() {
        return appInfoUid;
    }

    public void setAppInfoUid(Integer appInfoUid) {
        this.appInfoUid = appInfoUid;
    }

    public String getSourceHostname() {
        return sourceHostname;
    }

    public void setSourceHostname(String sourceHostname) {
        this.sourceHostname = sourceHostname;
    }

    public String getSourceIpAddress() {
        return sourceIpAddress;
    }

    public void setSourceIpAddress(String sourceIpAddress) {
        this.sourceIpAddress = sourceIpAddress;
    }

    public String getDestinationHostName() {
        return destinationHostName;
    }

    public void setDestinationHostName(String destinationHostName) {
        this.destinationHostName = destinationHostName;
    }

    public String getDestinationIpAddress() {
        return destinationIpAddress;
    }

    public void setDestinationIpAddress(String destinationIpAddress) {
        this.destinationIpAddress = destinationIpAddress;
    }

    public String getDestinationPort() {
        return destinationPort;
    }

    public void setDestinationPort(String destinationPort) {
        this.destinationPort = destinationPort;
    }

    public String getIpStatus() {
        return ipStatus;
    }

    public void setIpStatus(String ipStatus) {
        this.ipStatus = ipStatus;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getModifiedAt() {
        return modifiedAt;
    }

    public void setModifiedAt(Timestamp modifiedAt) {
        this.modifiedAt = modifiedAt;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }
}