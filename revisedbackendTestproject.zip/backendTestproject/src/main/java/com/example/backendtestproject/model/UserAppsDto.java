package com.example.backendtestproject.model;

import lombok.Data;
import java.sql.Timestamp;


public class UserAppsDto {

    private Integer applicationInfoId;
    private Integer userId;
    private Timestamp created_at;
    private String created_by;
    private Timestamp modified_at;
    private String modified_by;


    public Integer getApplicationInfoId() {
        return applicationInfoId;
    }

    public void setApplicationInfoId(Integer applicationInfoId) {
        this.applicationInfoId = applicationInfoId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Timestamp getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Timestamp created_at) {
        this.created_at = created_at;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public Timestamp getModified_at() {
        return modified_at;
    }

    public void setModified_at(Timestamp modified_at) {
        this.modified_at = modified_at;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }
}
